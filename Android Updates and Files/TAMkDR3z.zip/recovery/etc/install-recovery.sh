#!/system/bin/sh
if ! applypatch -c MTD:recovery:3866624:1b482da6a36597394a0fb3ebdee5e2d4b9b38a36; then
  log -t recovery "Installing new recovery image"
  applypatch MTD:boot:3526656:537bd5ccdfc4dcad7fdf6a81975d3d11d511abb1 MTD:recovery 1b482da6a36597394a0fb3ebdee5e2d4b9b38a36 3866624 537bd5ccdfc4dcad7fdf6a81975d3d11d511abb1:/system/recovery-from-boot.p
else
  log -t recovery "Recovery image already installed"
fi
